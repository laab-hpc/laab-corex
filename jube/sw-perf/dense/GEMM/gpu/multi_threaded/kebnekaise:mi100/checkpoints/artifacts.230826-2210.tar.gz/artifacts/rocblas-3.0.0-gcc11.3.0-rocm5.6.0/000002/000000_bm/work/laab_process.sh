#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/gpu/multi_threaded" \
    --system kebnekaise:mi100 \
    --lib rocblas \
    --version 3.0.0 \
    --toolchain gcc11.3.0-rocm5.6.0 \
    --np 1 \
    --work_dist "-n 1 -c 1 --gpus=1" \
    --pinning="NA" \
    --cb_id 2 \
    --profile_dir "../../../profiles"
