#!/bin/bash
#SBATCH --job-name=gpu_mt_gemm
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --gpus=1
#SBATCH --time=00:20:00
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A hpc2n2026-184
#SBATCH -C a100

set -euo pipefail

INPUTS_DIR="${INPUTS_DIR:-../../inputs}"
REPS="${REPS:-5}"

lscpu > cpu_info.txt
lspci > pci_info.txt

export LAAB_BUILD_DIR=$(pwd)/build
export LAAB_TRACE_DIR=$(pwd)/traces

module purge
module load GCC/14.3.0 CUDA/12.9.1

make -C ../../src/ clean
make -C ../../src/ 

ldd "$LAAB_BUILD_DIR/gemm_cu.exe" > ldd.txt

mkdir -p "$LAAB_TRACE_DIR"

srun "$LAAB_BUILD_DIR/gemm_cu.exe" -A "$INPUTS_DIR/dense/M15000x15000-float64-gen.dense" -B "$INPUTS_DIR/dense/M15000x15000-float64-gen.dense" --reps "$REPS" --tag "fp64"
srun "$LAAB_BUILD_DIR/gemm_cu.exe" -A "$INPUTS_DIR/dense/M15000x15000-float32-gen.dense" -B "$INPUTS_DIR/dense/M15000x15000-float32-gen.dense" --reps "$REPS" --tag "fp32"
srun "$LAAB_BUILD_DIR/gemm_cu.exe" -A "$INPUTS_DIR/dense/M15000x15000-complex128-gen.dense" -B "$INPUTS_DIR/dense/M15000x15000-complex128-gen.dense" --reps "$REPS" --tag "cmplx128"

rm -rf "$LAAB_BUILD_DIR"

bash laab_process.sh
