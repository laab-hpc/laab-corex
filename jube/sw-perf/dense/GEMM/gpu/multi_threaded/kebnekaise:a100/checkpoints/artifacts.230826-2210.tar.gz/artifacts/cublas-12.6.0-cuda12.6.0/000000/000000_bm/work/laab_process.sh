#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/gpu/multi_threaded" \
    --system kebnekaise:a100 \
    --lib cublas \
    --version 12.6.0 \
    --toolchain cuda12.6.0 \
    --np 1 \
    --work_dist "-n 1 -c 1 --gpus=1" \
    --pinning="NA" \
    --cb_id 0 \
    --profile_dir "../../../profiles"
