#!/bin/bash
#SBATCH --job-name=cpu_mt_gemm
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --time=00:20:00
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A cstao
#SBATCH -p dc-cpu

set -euo pipefail

## Generate input matrices! See ../../src/README.md
INPUTS_DIR="${INPUTS_DIR:-../../inputs}"
REPS="${REPS:-5}"

lscpu > cpu_info.txt 

export LAAB_BUILD_DIR=$(pwd)/build
export LAAB_TRACE_DIR=$(pwd)/traces

module purge
module load Stages/2025
module load GCC/13.3.0 OpenBLAS/0.3.27 FlexiBLAS/3.4.4

make -C ../../src/ clean
make -C ../../src/ LD_BLAS=-lopenblas

ldd $LAAB_BUILD_DIR/gemm.exe > ldd.txt

NT=4
export OMP_NUM_THREADS=$NT
mkdir -p $LAAB_TRACE_DIR

srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M3000x3000-float64-gen.dense -B $INPUTS_DIR/dense/M3000x3000-float64-gen.dense --reps "$REPS" --tag "fp64"
srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M3000x3000-float32-gen.dense -B $INPUTS_DIR/dense/M3000x3000-float32-gen.dense --reps "$REPS" --tag "fp32"
srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M3000x3000-complex128-gen.dense -B $INPUTS_DIR/dense/M3000x3000-complex128-gen.dense --reps "$REPS" --tag "cmplx128"

srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M6000x100-float64-gen.dense -B $INPUTS_DIR/dense/M100x100-float64-gen.dense --reps "$REPS" --tag "fp64-thin"
srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M6000x100-float32-gen.dense -B $INPUTS_DIR/dense/M100x100-float32-gen.dense --reps "$REPS" --tag "fp32-thin"
srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M6000x100-complex128-gen.dense -B $INPUTS_DIR/dense/M100x100-complex128-gen.dense --reps "$REPS" --tag "cmplx128-thin"

srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M6000x100-float64-gen.dense -B $INPUTS_DIR/dense/M100x6000-float64-gen.dense --reps "$REPS" --tag "fp64-cov"
srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M6000x100-float32-gen.dense -B $INPUTS_DIR/dense/M100x6000-float32-gen.dense --reps "$REPS" --tag "fp32-cov"
srun -c $NT "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M6000x100-complex128-gen.dense -B $INPUTS_DIR/dense/M100x6000-complex128-gen.dense --reps "$REPS" --tag "cmplx128-cov"

rm -rf $LAAB_BUILD_DIR

source /p/project1/ccstao/sankaran2/projects/p_laab/venv/activate.sh

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system jureca:zen2 \
    --lib openblas \
    --version 0.3.27 \
    --toolchain gcc13.3 \
    --np 4 \
    --work_dist "-n 1 -c 4" \
    --cb_id 0 \
    --profile_dir "../../../profiles"