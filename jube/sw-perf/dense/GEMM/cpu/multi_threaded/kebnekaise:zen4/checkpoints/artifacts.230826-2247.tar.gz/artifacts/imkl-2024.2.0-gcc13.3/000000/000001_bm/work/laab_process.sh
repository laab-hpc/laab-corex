#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system kebnekaise:zen4 \
    --lib imkl \
    --version 2024.2.0 \
    --toolchain gcc13.3 \
    --np 4 \
    --work_dist "-n 1 -c 4" \
    --pinning="--cpu_bind=cores --distribution=block:block" \
    --cb_id 0 \
    --profile_dir "../../../profiles"