#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system kebnekaise:zen4 \
    --lib openblas \
    --version 0.3.23 \
    --toolchain gcc12.3 \
    --np 1 \
    --work_dist "-n 1 -c 1" \
    --pinning="--cpu_bind=cores --distribution=block:block" \
    --cb_id 2 \
    --profile_dir "../../../profiles"