#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system kebnekaise:zen4 \
    --lib aocblas \
    --version 5.1 \
    --toolchain gcc14.3 \
    --np 1 \
    --work_dist "-n 1 -c 1" \
    --pinning="--cpu_bind=cores --distribution=block:block" \
    --cb_id 1 \
    --profile_dir "../../../profiles"