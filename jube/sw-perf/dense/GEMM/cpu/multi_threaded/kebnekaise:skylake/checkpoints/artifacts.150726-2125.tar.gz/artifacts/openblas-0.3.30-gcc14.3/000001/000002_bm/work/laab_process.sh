#!/bin/bash

module purge
module load GCC/14.3.0 Python/3.13.5
source /proj/nobackup/aravind/LAAB/inspectors/laab_inspector/venv-prod/bin/activate

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system kebnekaise:skylake \
    --lib openblas \
    --version 0.3.30 \
    --toolchain gcc14.3 \
    --np 14 \
    --work_dist "-n 1 -c 14" \
    --pinning="--cpu_bind=cores --distribution=block:block" \
    --cb_id 1 \
    --profile_dir "../../../profiles"