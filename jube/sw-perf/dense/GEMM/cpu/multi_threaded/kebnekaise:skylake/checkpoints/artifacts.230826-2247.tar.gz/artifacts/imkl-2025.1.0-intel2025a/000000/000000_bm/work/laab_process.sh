#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system kebnekaise:skylake \
    --lib imkl \
    --version 2025.1.0 \
    --toolchain intel2025a \
    --np 1 \
    --work_dist "-n 1 -c 1" \
    --pinning="--cpu_bind=cores --distribution=block:block" \
    --cb_id 0 \
    --profile_dir "../../../profiles"