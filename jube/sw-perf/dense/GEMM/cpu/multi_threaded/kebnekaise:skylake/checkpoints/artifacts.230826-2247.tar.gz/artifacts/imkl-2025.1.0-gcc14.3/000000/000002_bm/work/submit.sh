#!/bin/bash
#SBATCH --job-name=cpu_mt_gemm
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=14
#SBATCH --time=00:20:00
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A hpc2n2026-184
#SBATCH -C skylake

set -euo pipefail

## Generate input matrices! See ../../src/README.md
INPUTS_DIR="${INPUTS_DIR:-../../inputs}"
REPS="${REPS:-5}"

lscpu > cpu_info.txt 

export LAAB_BUILD_DIR=$(pwd)/build
export LAAB_TRACE_DIR=$(pwd)/traces

module purge
module load GCC/14.3.0 imkl/2025.1.0 FlexiBLAS/3.4.5

make -C ../../src/ clean
make -C ../../src/ LD_BLAS=-lmkl_rt

ldd $LAAB_BUILD_DIR/gemm.exe > ldd.txt

NT=14
export OMP_NUM_THREADS=$NT
mkdir -p $LAAB_TRACE_DIR

srun -c $NT --cpu_bind=cores --distribution=block:block "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M3000x3000-float64-gen.dense -B $INPUTS_DIR/dense/M3000x3000-float64-gen.dense --reps "$REPS" --tag "fp64"
srun -c $NT --cpu_bind=cores --distribution=block:block "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M3000x3000-float32-gen.dense -B $INPUTS_DIR/dense/M3000x3000-float32-gen.dense --reps "$REPS" --tag "fp32"
srun -c $NT --cpu_bind=cores --distribution=block:block "$LAAB_BUILD_DIR/gemm.exe" -A $INPUTS_DIR/dense/M3000x3000-complex128-gen.dense -B $INPUTS_DIR/dense/M3000x3000-complex128-gen.dense --reps "$REPS" --tag "cmplx128"

rm -rf $LAAB_BUILD_DIR

bash laab_process.sh