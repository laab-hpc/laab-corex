#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system kebnekaise:skylake \
    --lib openblas \
    --version 0.3.27 \
    --toolchain gcc13.3 \
    --np 14 \
    --work_dist "-n 1 -c 14" \
    --pinning="--cpu_bind=cores --distribution=block:block" \
    --cb_id 2 \
    --profile_dir "../../../profiles"