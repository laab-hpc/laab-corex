#!/bin/bash

module purge
module load GCC/14.3.0 Python/3.13.5
source /proj/nobackup/aravind/LAAB/inspectors/laab_inspector/venv-prod/bin/activate

laab-process traces/ \
    --name "dense/GEMM/cpu/multi_threaded" \
    --system kebnekaise:skylake \
    --lib imkl \
    --version 2024.2.0 \
    --toolchain gcc13.3 \
    --np 1 \
    --work_dist "-n 1 -c 1" \
    --pinning="--cpu_bind=cores --distribution=block:block" \
    --cb_id 2 \
    --profile_dir "../../../profiles"