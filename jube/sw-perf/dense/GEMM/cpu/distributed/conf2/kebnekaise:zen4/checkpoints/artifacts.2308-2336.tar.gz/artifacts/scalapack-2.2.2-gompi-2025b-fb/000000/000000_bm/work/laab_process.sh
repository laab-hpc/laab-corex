#!/bin/bash

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-corex/venvs/laab-kebnekaise/activate.sh

laab-process traces/ \
    --name "dense/GEMM/cpu/distributed" \
    --system kebnekaise:zen4 \
    --lib scalapack \
    --version 2.2.2 \
    --toolchain gompi-2025b-fb \
    --np 24 \
    --work_dist "-N 1 -tpN 24 -c 1" \
    --pinning="--cpu-bind=threads --distribution=block:cyclic:cyclic --threads-per-core=1" \
    --cb_id 0 \
    --options "single-threaded" \
    --profile_dir "../../../profiles"