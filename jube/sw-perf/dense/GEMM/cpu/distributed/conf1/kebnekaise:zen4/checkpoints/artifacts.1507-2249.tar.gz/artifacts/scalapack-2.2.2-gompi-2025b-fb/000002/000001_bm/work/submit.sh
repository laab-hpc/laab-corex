#!/bin/bash
#SBATCH --job-name=pxgemm
#SBATCH --nodes=2
#SBATCH --ntasks=4
#SBATCH --ntasks-per-node=2
#SBATCH --cpus-per-task=24
#SBATCH --time=01:00:00
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A hpc2n2026-184
#SBATCH -C zen4

set -euo pipefail

## Generate input matrices! See ../../src/README.md
INPUTS_DIR="${INPUTS_DIR:-../../inputs}"
REPS="${REPS:-5}"

lscpu > cpu_info.txt 

export LAAB_BUILD_DIR=$(pwd)/build
export LAAB_TRACE_DIR=$(pwd)/traces

module purge
module load GCC/14.3.0 OpenMPI/5.0.8 ScaLAPACK/2.2.2-fb

make -C ../../src/ clean
make -C ../../src/ LD_SCALAPACK=-lscalapack LD_BLAS=-lopenblas

ldd $LAAB_BUILD_DIR/pdgemm.exe > ldd.txt

export OMP_NUM_THREADS=24
mkdir -p $LAAB_TRACE_DIR

srun -N 2 -n 4 --ntasks-per-node 2 -c 24 --cpu-bind=threads --distribution=block:cyclic:cyclic --threads-per-core=1 "$LAAB_BUILD_DIR/pdgemm.exe" -A $INPUTS_DIR/dense/M15000x15000-float64-gen.dense -B $INPUTS_DIR/dense/M15000x15000-float64-gen.dense -b 256 --reps "$REPS" --tag "fp64-b256"
srun -N 2 -n 4 --ntasks-per-node 2 -c 24 --cpu-bind=threads --distribution=block:cyclic:cyclic --threads-per-core=1 "$LAAB_BUILD_DIR/pdgemm.exe" -A $INPUTS_DIR/dense/M15000x15000-float64-gen.dense -B $INPUTS_DIR/dense/M15000x15000-float64-gen.dense -b 512 --reps "$REPS" --tag "fp64-b512"
srun -N 2 -n 4 --ntasks-per-node 2 -c 24 --cpu-bind=threads --distribution=block:cyclic:cyclic --threads-per-core=1 "$LAAB_BUILD_DIR/pdgemm.exe" -A $INPUTS_DIR/dense/M15000x15000-float64-gen.dense -B $INPUTS_DIR/dense/M15000x15000-float64-gen.dense -b 1000 --reps "$REPS" --tag "fp64-b1000"


rm -rf $LAAB_BUILD_DIR

bash laab_process.sh