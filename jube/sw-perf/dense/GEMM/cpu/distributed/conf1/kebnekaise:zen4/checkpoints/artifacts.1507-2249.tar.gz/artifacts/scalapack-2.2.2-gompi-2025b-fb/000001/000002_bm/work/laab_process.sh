#!/bin/bash

module purge
module load GCC/14.3.0 Python/3.13.5
source /proj/nobackup/aravind/LAAB/inspectors/laab_inspector/venv-prod/bin/activate

laab-process traces/ \
    --name "dense/GEMM/cpu/distributed" \
    --system kebnekaise:zen4 \
    --lib scalapack \
    --version 2.2.2 \
    --toolchain gompi-2025b-fb \
    --np 192 \
    --work_dist "-N 4 -tpN 2 -c 24" \
    --pinning="--cpu-bind=threads --distribution=block:cyclic:cyclic --threads-per-core=1" \
    --cb_id 1 \
    --options "multi-threaded" \
    --profile_dir "../../../profiles"